# ML-Powered Security System with Decoy

A comprehensive security system featuring dynamic firewall rules, ML-based threat detection, and decoy honeypot.

## Quick Start

1. Build and start the system:
```bash
docker-compose up --build
```

2. Train the ML model:

```bash
cd analyzer/ml_model
python train_model.py
```

3. Run tests:

```bash
python tests/test_system.py
```

Components
Firewall: Dynamic iptables rules management

Analyzer: ML-powered traffic analysis

Main System: Production web application

Decoy System: Honeypot for suspicious traffic

Testing
Use the provided test scripts to verify system functionality.

text

### 2. Firewall Component

**firewall/Dockerfile**
```dockerfile
FROM ubuntu:20.04

RUN apt-get update && apt-get install -y \
    iptables \
    python3 \
    python3-pip \
    net-tools \
    tcpdump \
    curl

WORKDIR /app
COPY scripts/ ./scripts/
COPY requirements.txt .

RUN pip3 install -r requirements.txt
RUN chmod +x scripts/*.sh

CMD ["./scripts/iptables-setup.sh"]