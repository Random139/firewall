import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pickle
import os

def generate_training_data():
    np.random.seed(42)
    n_samples = 5000
    data = {
        'packet_size': np.concatenate([
            np.random.randint(500, 1500, n_samples//2),  # Normal
            np.random.randint(40, 100, n_samples//2),    # Malicious
        ]),
        'packet_rate': np.concatenate([
            np.random.poisson(5, n_samples//2),          # Normal
            np.random.poisson(100, n_samples//2),        # Malicious
        ]),
        'src_port': np.random.randint(1024, 65535, n_samples),
        'dst_port': np.random.choice([80, 443, 22, 3389], n_samples),
        'protocol': np.random.choice([6, 17], n_samples),
        'flags': np.random.randint(0, 255, n_samples),
        'duration': np.concatenate([
            np.random.exponential(2, n_samples//2),      # Normal
            np.random.exponential(0.1, n_samples//2),    # Malicious
        ]),
        'payload_length': np.random.randint(0, 1500, n_samples),
        'is_weekend': np.random.choice([0, 1], n_samples),
        'hour_of_day': np.random.randint(0, 24, n_samples),
    }
    
    df = pd.DataFrame(data)
    
    malicious_conditions = (
        (df['packet_rate'] > 50) |
        (df['packet_size'] < 100) |
        (df['duration'] < 0.5) & (df['packet_rate'] > 10)
    )
    
    df['is_malicious'] = malicious_conditions.astype(int)
    
    return df

def train_model():
    print("Generating training data...")
    df = generate_training_data()
    
    features = [
        'packet_size', 'packet_rate', 'src_port', 'dst_port', 
        'protocol', 'flags', 'duration', 'payload_length',
        'is_weekend', 'hour_of_day'
    ]
    
    X = df[features]
    y = df['is_malicious']

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    print("Training Random Forest model...")
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        random_state=42,
        class_weight='balanced'
    )
    
    model.fit(X_scaled, y)

    model_data = {
        'model': model,
        'scaler': scaler,
        'features': features
    }
    
    with open('model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    print("Model saved as model.pkl")

if __name__ == "__main__":
    train_model()