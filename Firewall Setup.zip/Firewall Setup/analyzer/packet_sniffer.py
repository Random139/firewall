from scapy.all import sniff, IP, TCP, UDP, ICMP
import json
import requests
from datetime import datetime
import threading
import time

class PacketSniffer:
    def __init__(self, analyzer_url="http://localhost:5000", interface=None):
        self.analyzer_url = analyzer_url
        self.packet_buffer = []
        self.interface = interface
        self.stats = {
            'total_packets': 0,
            'suspicious_packets': 0,
            'start_time': datetime.now(),
            'last_analysis': datetime.now()
        }
        self.running = True
        
    def process_packet(self, packet):
        """Process individual packets"""
        if not self.running:
            return
            
        if IP in packet:
            packet_data = self.extract_packet_info(packet)
            self.packet_buffer.append(packet_data)
            self.stats['total_packets'] += 1
            if len(self.packet_buffer) >= 5 or (datetime.now() - self.stats['last_analysis']).seconds >= 2:
                self.send_to_analyzer()
                
    def extract_packet_info(self, packet):
        """Extract relevant information from packet"""
        ip_layer = packet[IP]
        
        data = {
            'src_ip': ip_layer.src,
            'dst_ip': ip_layer.dst,
            'packet_size': len(packet),
            'timestamp': datetime.now().isoformat(),
            'protocol': ip_layer.proto,
            'packet_rate': 1,  
            'duration': 0.1,   
        }
        
        if TCP in packet:
            tcp_layer = packet[TCP]
            data.update({
                'src_port': tcp_layer.sport,
                'dst_port': tcp_layer.dport,
                'flags': tcp_layer.flags,
                'payload': str(tcp_layer.payload)[:100] if tcp_layer.payload else ''
            })
        elif UDP in packet:
            udp_layer = packet[UDP]
            data.update({
                'src_port': udp_layer.sport,
                'dst_port': udp_layer.dport,
                'payload': str(udp_layer.payload)[:100] if udp_layer.payload else ''
            })
        else:
            data.update({
                'src_port': 0,
                'dst_port': 0,
                'flags': 0,
                'payload': ''
            })
            
        data['payload_length'] = len(data['payload'])
            
        return data
        
    def send_to_analyzer(self):
        """Send buffered packets to analyzer"""
        if not self.packet_buffer:
            return
            
        try:
            for packet_data in self.packet_buffer:
                response = requests.post(
                    f"{self.analyzer_url}/analyze",
                    json=packet_data,
                    timeout=3
                )
                
                if response.status_code == 200:
                    result = response.json()
                    decision = result.get('decision', {})
                    if decision.get('action') in ['block', 'decoy']:
                        self.stats['suspicious_packets'] += 1
                        print(f"🚨 {decision['action'].upper()}: {decision['reason']}")
                        
        except Exception as e:
            print(f"Error sending to analyzer: {e}")
            
        self.packet_buffer.clear()
        self.stats['last_analysis'] = datetime.now()
        
    def start_sniffing(self):
        """Start packet sniffing"""
        print(f"Starting packet sniffer on interface {self.interface or 'default'}...")
        try:
            sniff(
                prn=self.process_packet,
                store=False,
                iface=self.interface,
                filter="ip and (tcp or udp)",
                stop_filter=lambda x: not self.running
            )
        except Exception as e:
            print(f"Sniffing error: {e}")
        
    def start_periodic_analysis(self):
        """Periodically send buffered packets for analysis"""
        while self.running:
            self.send_to_analyzer()
            time.sleep(2)
            
    def stop(self):
        """Stop the sniffer"""
        self.running = False

def start_sniffer(interface=None):
    sniffer = PacketSniffer(interface=interface)
    
    analysis_thread = threading.Thread(target=sniffer.start_periodic_analysis)
    analysis_thread.daemon = True
    analysis_thread.start()
    
    try:
        sniffer.start_sniffing()
    except KeyboardInterrupt:
        print("\nStopping packet sniffer...")
        sniffer.stop()

if __name__ == "__main__":
    import sys
    interface = sys.argv[1] if len(sys.argv) > 1 else None
    start_sniffer(interface)