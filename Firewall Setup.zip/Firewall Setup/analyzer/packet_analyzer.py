import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pickle
import json
import time
from datetime import datetime
from flask import Flask, jsonify, request
import threading
import os

app = Flask(__name__)

class TrafficAnalyzer:
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.features = [
            'packet_size', 'packet_rate', 'src_port', 'dst_port', 
            'protocol', 'flags', 'duration', 'payload_length',
            'is_weekend', 'hour_of_day'
        ]
        self.load_model()
        self.suspicious_ips = set()
        self.pending_decisions = []
        self.packet_count = 0
        
    def load_model(self):
        model_path = 'ml_model/model.pkl'
        if os.path.exists(model_path):
            try:
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.model = model_data['model']
                    self.scaler = model_data['scaler']
                print("ML model loaded successfully")
            except Exception as e:
                print(f"Error loading model: {e}. Training new model...")
                self.train_emergency_model()
        else:
            print("No pre-trained model found. Training new model...")
            self.train_emergency_model()
            
    def train_emergency_model(self):
        """Train a basic model for immediate use"""
        from sklearn.ensemble import RandomForestClassifier
        np.random.seed(42)
        n_samples = 1000
        
        X = np.random.rand(n_samples, 10)
        y = (X[:, 0] > 0.7) | (X[:, 1] < 0.3)
        self.scaler.fit(X)
        X_scaled = self.scaler.transform(X)
        
        self.model = RandomForestClassifier(n_estimators=50, random_state=42)
        self.model.fit(X_scaled, y)
        
        print("Emergency model trained")
    
    def extract_features(self, packet_data):
        """Extract features from packet data for ML model"""
        features = [
            packet_data.get('packet_size', 0),
            packet_data.get('packet_rate', 0),
            packet_data.get('src_port', 0),
            packet_data.get('dst_port', 0),
            packet_data.get('protocol', 0),
            packet_data.get('flags', 0),
            packet_data.get('duration', 0),
            len(packet_data.get('payload', '')),
            datetime.now().weekday() >= 5,  
            datetime.now().hour  
        ]
        return np.array(features).reshape(1, -1)
    
    def analyze_traffic(self, packet_data):
        """Analyze traffic using ML model"""
        try:
            features = self.extract_features(packet_data)
            features_scaled = self.scaler.transform(features)
            
            prediction = self.model.predict(features_scaled)
            probability = self.model.predict_proba(features_scaled)
            
            self.packet_count += 1
            
            return {
                'is_malicious': bool(prediction[0]),
                'confidence': float(max(probability[0])),
                'ip': packet_data.get('src_ip', 'unknown'),
                'port': packet_data.get('dst_port', 0),
                'timestamp': datetime.now().isoformat(),
                'packet_id': self.packet_count
            }
        except Exception as e:
            print(f"Analysis error: {e}")
            return {
                'is_malicious': False,
                'confidence': 0.0,
                'ip': packet_data.get('src_ip', 'unknown'),
                'port': packet_data.get('dst_port', 0),
                'timestamp': datetime.now().isoformat(),
                'error': str(e)
            }
    
    def make_decision(self, analysis_result):
        """Make firewall decision based on analysis"""
        if analysis_result.get('error'):
            return {
                'action': 'allow',
                'ip': analysis_result['ip'],
                'reason': 'Analysis error - default allow'
            }
            
        if analysis_result['is_malicious'] and analysis_result['confidence'] > 0.8:
            return {
                'action': 'block',
                'ip': analysis_result['ip'],
                'reason': f"Malicious traffic detected (confidence: {analysis_result['confidence']:.2f})",
                'confidence': analysis_result['confidence'],
                'timestamp': analysis_result['timestamp']
            }
        elif analysis_result['confidence'] > 0.6:
            return {
                'action': 'decoy',
                'ip': analysis_result['ip'],
                'port': analysis_result['port'],
                'reason': f"Suspicious traffic - redirecting to decoy (confidence: {analysis_result['confidence']:.2f})",
                'confidence': analysis_result['confidence'],
                'timestamp': analysis_result['timestamp']
            }
        else:
            return {
                'action': 'allow',
                'ip': analysis_result['ip'],
                'port': analysis_result['port'],
                'reason': 'Normal traffic',
                'confidence': analysis_result['confidence'],
                'timestamp': analysis_result['timestamp']
            }

@app.route('/analyze', methods=['POST'])
def analyze_packet():
    data = request.json
    analyzer = app.config['analyzer']
    
    result = analyzer.analyze_traffic(data)
    decision = analyzer.make_decision(result)
    
    analyzer.pending_decisions.append(decision)
    
    print(f"Analysis: {decision['action']} for {decision['ip']} - {decision['reason']}")
    
    return jsonify({
        'analysis': result,
        'decision': decision
    })

@app.route('/decisions', methods=['GET'])
def get_decisions():
    analyzer = app.config['analyzer']
    decisions = analyzer.pending_decisions.copy()
    analyzer.pending_decisions.clear()
    return jsonify(decisions)

@app.route('/health', methods=['GET'])
def health_check():
    analyzer = app.config['analyzer']
    return jsonify({
        'status': 'healthy',
        'model_loaded': analyzer.model is not None,
        'packets_processed': analyzer.packet_count,
        'suspicious_ips_count': len(analyzer.suspicious_ips)
    })

def start_analyzer():
    analyzer = TrafficAnalyzer()
    app.config['analyzer'] = analyzer
    print("Starting Traffic Analyzer on port 5000...")
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)

if __name__ == "__main__":
    start_analyzer()