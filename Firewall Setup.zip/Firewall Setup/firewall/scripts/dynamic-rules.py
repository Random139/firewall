import json
import subprocess
import time
import requests
from datetime import datetime

class DynamicFirewall:
    def __init__(self):
        self.allowed_ports = [80, 443, 22]
        self.blocked_ips = set()
        self.analyzer_url = "http://localhost:5000"
        
    def update_rules(self, decision):
        """Update firewall rules based on analyzer decision"""
        if decision.get('action') == 'block':
            ip = decision.get('ip')
            if ip and ip not in self.blocked_ips:
                self.block_ip(ip)
        elif decision.get('action') == 'allow':
            port = decision.get('port')
            if port and port not in self.allowed_ports:
                self.allow_port(port)
            
    def block_ip(self, ip):
        try:
            subprocess.run(f"iptables -A INPUT -s {ip} -j DROP", shell=True, check=True)
            self.blocked_ips.add(ip)
            print(f"[FIREWALL] Blocked IP: {ip}")
        except subprocess.CalledProcessError as e:
            print(f"[FIREWALL] Error blocking IP {ip}: {e}")
            
    def allow_port(self, port):
        try:
            subprocess.run(f"iptables -A INPUT -p tcp --dport {port} -j ACCEPT", shell=True, check=True)
            self.allowed_ports.append(port)
            print(f"[FIREWALL] Allowed port: {port}")
        except subprocess.CalledProcessError as e:
            print(f"[FIREWALL] Error allowing port {port}: {e}")
            
    def monitor_traffic(self):
        print("[FIREWALL] Starting dynamic rules monitor...")
        while True:
            try:
                response = requests.get(f"{self.analyzer_url}/decisions", timeout=5)
                if response.status_code == 200:
                    decisions = response.json()
                    for decision in decisions:
                        self.update_rules(decision)
            except Exception as e:
                print(f"[FIREWALL] Error communicating with analyzer: {e}")
                
            time.sleep(5)

if __name__ == "__main__":
    firewall = DynamicFirewall()
    firewall.monitor_traffic()