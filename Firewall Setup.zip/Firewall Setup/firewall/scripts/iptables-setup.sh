#!/bin/bash

# Flush existing rules
iptables -F
iptables -X
iptables -t nat -F

# Default policies
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Allow established connections
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Allow loopback
iptables -A INPUT -i lo -j ACCEPT

# Initial allowed ports
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j ACCEPT

# Redirect suspicious traffic to decoy
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-ports 8081

echo "Firewall rules initialized"

# Start dynamic rules manager
python3 scripts/dynamic-rules.py