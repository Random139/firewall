import requests
import time
from datetime import datetime
import sys

def monitor_system():
    print("🔍 Starting Security System Monitor...")
    print("Press Ctrl+C to stop monitoring\n")
    
    try:
        while True:
            try:
                # Check analyzer health
                analyzer_response = requests.get("http://localhost:5000/health", timeout=2)
                analyzer_data = analyzer_response.json() if analyzer_response.status_code == 200 else {}
                
                # Check services
                main_system_up = requests.get("http://localhost:8080", timeout=2).status_code == 200
                decoy_system_up = requests.get("http://localhost:8081", timeout=2).status_code == 200
                
                # Get recent decisions
                decisions_response = requests.get("http://localhost:5000/decisions", timeout=2)
                recent_decisions = decisions_response.json() if decisions_response.status_code == 200 else []
                
                # Clear screen and display status
                print("\033[2J\033[H")  # Clear screen
                print(f"Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
                print("="*50)
                
                # System Status
                print("SYSTEM STATUS:")
                print(f"   Analyzer:       {' Healthy' if analyzer_data.get('status') == 'healthy' else '❌ Issues'}")
                print(f"   Main System:    {' Running' if main_system_up else '❌ Down'}")
                print(f"   Decoy System:   {' Running' if decoy_system_up else '❌ Down'}")
                print(f"   Packets Processed: {analyzer_data.get('packets_processed', 'N/A')}")
                
                # Recent Activity
                print(f"\n RECENT DECISIONS ({len(recent_decisions)}):")
                for decision in recent_decisions[-5:]:  # Last 5 decisions
                    action_icon = "🚫" if decision.get('action') == 'block' else "🎣" if decision.get('action') == 'decoy' else "✅"
                    print(f"   {action_icon} {decision.get('action', 'unknown').upper():6} {decision.get('ip', 'unknown'):15} - {decision.get('reason', '')}")
                
                if not recent_decisions:
                    print("   No recent decisions")
                
                # Statistics
                print(f"\nSTATISTICS:")
                print(f"   Suspicious IPs:  {analyzer_data.get('suspicious_ips_count', 0)}")
                print(f"   Model Loaded:    {'Yes' if analyzer_data.get('model_loaded') else '❌ No'}")
                
                print("\n" + "="*50)
                print("Monitoring... (Ctrl+C to stop)")
                
            except Exception as e:
                print(f"Monitoring error: {e}")
            
            time.sleep(3)
            
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped.")

if __name__ == "__main__":
    monitor_system()