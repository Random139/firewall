import requests
import time
import subprocess
import threading
import sys
from datetime import datetime

class SecuritySystemTester:
    def __init__(self):
        self.base_url = "http://localhost:8080"
        self.decoy_url = "http://localhost:8081"
        self.analyzer_url = "http://localhost:5000"
        
    def print_status(self, message, status=None):
        """Print formatted status message"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        if status is True:
            print(f"[{timestamp}] ✅ {message}")
        elif status is False:
            print(f"[{timestamp}] ❌ {message}")
        else:
            print(f"[{timestamp}] 🔍 {message}")
    
    def test_service_health(self):
        """Test if all services are running"""
        self.print_status("Testing service health...")
        
        services = {
            'Main System': self.base_url,
            'Decoy System': self.decoy_url,
            'Analyzer': f"{self.analyzer_url}/health"
        }
        
        all_healthy = True
        for name, url in services.items():
            try:
                if name == 'Analyzer':
                    response = requests.get(url, timeout=5)
                    data = response.json()
                    if data.get('status') == 'healthy':
                        self.print_status(f"{name}: Healthy", True)
                    else:
                        self.print_status(f"{name}: Unhealthy", False)
                        all_healthy = False
                else:
                    response = requests.get(url, timeout=5)
                    if response.status_code == 200:
                        self.print_status(f"{name}: Running", True)
                    else:
                        self.print_status(f"{name}: Not responding", False)
                        all_healthy = False
            except Exception as e:
                self.print_status(f"{name}: Error - {e}", False)
                all_healthy = False
                
        return all_healthy
    
    def test_normal_traffic(self):
        """Test legitimate traffic is allowed"""
        self.print_status("Testing normal traffic flow...")
        try:
            response = requests.get(self.base_url, timeout=5)
            if "Main Production System" in response.text:
                self.print_status("Normal traffic to main system: ALLOWED", True)
                return True
            else:
                self.print_status("Unexpected response from main system", False)
                return False
        except Exception as e:
            self.print_status(f"Normal traffic failed: {e}", False)
            return False
    
    def test_firewall_redirect(self):
        """Test if suspicious traffic gets redirected to decoy"""
        self.print_status("Testing firewall redirect mechanism...")
        
        # Create a suspicious-looking request
        suspicious_headers = {
            'User-Agent': 'nmap',
            'X-Forwarded-For': '192.168.1.100'
        }
        
        try:
            response = requests.get(self.base_url, headers=suspicious_headers, timeout=5)
            if "SYSTEM ADMINISTRATION PANEL" in response.text.upper():
                self.print_status("Suspicious traffic redirected to decoy: WORKING", True)
                return True
            else:
                self.print_status("Suspicious traffic not redirected", False)
                return False
        except Exception as e:
            self.print_status(f"Redirect test failed: {e}", False)
            return False
    
    def test_ml_detection(self):
        """Test ML model with known attack patterns"""
        self.print_status("Testing ML-based detection...")
        
        # Send suspicious packet patterns to analyzer
        suspicious_packet = {
            'packet_size': 40,  # Very small (probing)
            'packet_rate': 1500,  # Very high (flood)
            'src_port': 54321,
            'dst_port': 22,  # SSH port
            'protocol': 6,  # TCP
            'flags': 0,  # Null scan
            'duration': 0.05,
            'payload_length': 0,
            'src_ip': '192.168.1.666'  # Fake IP
        }
        
        try:
            response = requests.post(
                f"{self.analyzer_url}/analyze",
                json=suspicious_packet,
                timeout=5
            )
            result = response.json()
            
            if result['decision']['action'] in ['block', 'decoy']:
                self.print_status(f"ML detection: WORKING (Action: {result['decision']['action']})", True)
                return True
            else:
                self.print_status("ML detection: MISSED suspicious pattern", False)
                return False
        except Exception as e:
            self.print_status(f"ML test failed: {e}", False)
            return False
    
    def test_dos_simulation(self):
        """Simulate Denial of Service attack"""
        self.print_status("Testing DoS detection...")
        
        def send_requests():
            for i in range(10):  # Rapid requests
                try:
                    requests.get(self.base_url, timeout=1)
                except:
                    pass
        
        # Start multiple threads to simulate high traffic
        threads = []
        for _ in range(3):
            t = threading.Thread(target=send_requests)
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Check for blocking decisions
        time.sleep(3)
        try:
            response = requests.get(f"{self.analyzer_url}/decisions")
            decisions = response.json()
            if any(decision.get('action') == 'block' for decision in decisions):
                self.print_status("DoS detection and blocking: WORKING", True)
                return True
            else:
                self.print_status("DoS detection: NOT TRIGGERED (may need more traffic)", False)
                return False
        except Exception as e:
            self.print_status(f"DoS test failed: {e}", False)
            return False
    
    def check_firewall_rules(self):
        """Check if firewall rules are active"""
        self.print_status("Checking firewall rules...")
        try:
            result = subprocess.run(
                "docker exec security-firewall iptables -L INPUT -n | head -20",
                shell=True,
                capture_output=True,
                text=True
            )
            rules = result.stdout
            if "DROP" in rules and "ACCEPT" in rules:
                self.print_status("Firewall rules are active", True)
                return True
            else:
                self.print_status("Firewall rules not properly configured", False)
                return False
        except Exception as e:
            self.print_status(f"Firewall check failed: {e}", False)
            return False
    
    def run_all_tests(self):
        """Run complete test suite"""
        print("\n" + "="*60)
        print("STARTING SECURITY SYSTEM COMPREHENSIVE TESTS")
        print("="*60 + "\n")
        
        # First check if services are running
        if not self.test_service_health():
            self.print_status("Some services are not healthy. Please start the system first.")
            return False
        
        time.sleep(2)
        
        tests = [
            self.test_normal_traffic,
            self.test_firewall_redirect,
            self.test_ml_detection,
            self.test_dos_simulation,
            self.check_firewall_rules
        ]
        
        results = []
        for test in tests:
            results.append(test())
            time.sleep(2)  # Delay between tests
            print()
        
        passed = sum(results)
        total = len(results)
        
        print("="*60)
        print(f"TEST SUMMARY: {passed}/{total} tests passed")
        
        if passed == total:
            print("ALL TESTS PASSED! Security system is working correctly.")
            print("The system is ready to protect against real threats.")
        else:
            print("SOME TESTS FAILED. Check system configuration and logs.")
            print("Run 'docker-compose logs' to see detailed logs.")
        
        print("="*60)
        return passed == total

if __name__ == "__main__":
    tester = SecuritySystemTester()
    success = tester.run_all_tests()
    sys.exit(0 if success else 1)