import requests
import threading
import time
import random
from datetime import datetime

class AttackSimulator:
    def __init__(self):
        self.target_url = "http://localhost:8080"
        self.analyzer_url = "http://localhost:5000"
        
    def simulate_port_scan(self):
        """Simulate port scanning behavior"""
        print("🔍 Simulating port scan...")
        
        # Rapid requests to different ports (simulated)
        for i in range(20):
            try:
                
                headers = {'User-Agent': 'nmap' if i % 3 == 0 else 'masscan'}
                requests.get(self.target_url, headers=headers, timeout=0.5)
            except:
                pass
            time.sleep(0.1)
        
        print("Port scan simulation completed")
    
    def simulate_dos_attack(self, duration=10):
        """Simulate Denial of Service attack"""
        print(f"Simulating DoS attack for {duration} seconds...")
        
        stop_attack = threading.Event()
        request_count = [0]
        
        def attack_worker():
            while not stop_attack.is_set():
                try:
                    requests.get(self.target_url, timeout=1)
                    request_count[0] += 1
                except:
                    pass
        
    
        threads = []
        for i in range(5):
            t = threading.Thread(target=attack_worker)
            threads.append(t)
            t.start()
        
        time.sleep(duration)
        stop_attack.set()
        
        for t in threads:
            t.join()
        
        print(f"DoS simulation completed: {request_count[0]} requests sent")
    
    def simulate_suspicious_patterns(self):
        """Send various suspicious patterns to trigger ML detection"""
        print("Simulating suspicious traffic patterns...")
        
        suspicious_patterns = [
            # Null scan pattern
            {
                'packet_size': 40,
                'packet_rate': 2000,
                'src_port': 12345,
                'dst_port': 22,
                'protocol': 6,
                'flags': 0,
                'duration': 0.01,
                'payload_length': 0,
                'src_ip': '10.1.1.100'
            },
            # Flood pattern
            {
                'packet_size': 60,
                'packet_rate': 5000,
                'src_port': 54321,
                'dst_port': 80,
                'protocol': 6,
                'flags': 2,
                'duration': 0.001,
                'payload_length': 10,
                'src_ip': '192.168.100.50'
            },
            # Weird protocol combination
            {
                'packet_size': 100,
                'packet_rate': 100,
                'src_port': 33333,
                'dst_port': 3389,
                'protocol': 255,  # Unknown protocol
                'flags': 255,
                'duration': 5.0,
                'payload_length': 80,
                'src_ip': '172.16.1.200'
            }
        ]
        
        for pattern in suspicious_patterns:
            try:
                response = requests.post(
                    f"{self.analyzer_url}/analyze",
                    json=pattern,
                    timeout=3
                )
                result = response.json()
                action = result['decision']['action']
                print(f"   Pattern: {action.upper()} - {result['decision']['reason']}")
            except Exception as e:
                print(f"   Error: {e}")
            
            time.sleep(1)
    
    def run_all_simulations(self):
        """Run all attack simulations"""
        print("Starting attack simulations\n")
        
        simulations = [
            ("Port Scan", self.simulate_port_scan),
            ("Suspicious Patterns", self.simulate_suspicious_patterns),
            ("DoS Attack", lambda: self.simulate_dos_attack(5))
        ]
        
        for name, simulation in simulations:
            print(f"\n{'='*50}")
            print(f"Running: {name}")
            print(f"{'='*50}")
            simulation()
            time.sleep(2)
        
        print(f"\n{'='*50}")
        print("All simulations completed!")
        print("Check the monitor to see detection results.")
        print(f"{'='*50}")

if __name__ == "__main__":
    simulator = AttackSimulator()
    simulator.run_all_simulations()